#include "RiskTool_com.hpp"


CRiskTool::CRiskTool()
{
  g_pModule->InitializeComponentInstanceEx(&m_hinst);
}
CRiskTool::~CRiskTool()
{
  if (m_hinst)
    g_pModule->TerminateInstance(&m_hinst);
}

HRESULT __stdcall CRiskTool::backtestPlantPortfolio(/*[in]*/long nargout, 
                                                    /*[in,out]*/VARIANT* results, 
                                                    /*[in,out]*/VARIANT* earnings, 
                                                    /*[in]*/VARIANT assets, 
                                                    /*[in]*/VARIANT startDate, 
                                                    /*[in]*/VARIANT endDate) {
  return( CallComFcn( "backtestPlantPortfolio", (int) nargout, 2, 3, results, earnings, 
                      &assets, &startDate, &endDate ) );
}


HRESULT __stdcall CRiskTool::simulatePlantPortfolio(/*[in]*/long nargout, 
                                                    /*[in,out]*/VARIANT* assetResults, 
                                                    /*[in,out]*/VARIANT* portResults, 
                                                    /*[in]*/VARIANT assets, 
                                                    /*[in]*/VARIANT startDate, 
                                                    /*[in]*/VARIANT endDate, 
                                                    /*[in]*/VARIANT Ntrials) {
  return( CallComFcn( "simulatePlantPortfolio", (int) nargout, 2, 4, assetResults, 
                      portResults, &assets, &startDate, &endDate, &Ntrials ) );
}

