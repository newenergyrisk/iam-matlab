#ifndef _PlantRisk_RiskTool_com_HPP
#define _PlantRisk_RiskTool_com_HPP 1

#include <windows.h>
#include "PlantRisk_idl.h"
#include "mclmcrrt.h"
#include "mclcom.h"
#include "mclxlmain.h"
#include "mclcomclass.h"

class CRiskTool : public CMCLClassImpl<IRiskTool, &IID_IRiskTool, CRiskTool, 
                                       &CLSID_RiskTool>
{
public:
  CRiskTool();
  ~CRiskTool();

  HRESULT __stdcall backtestPlantPortfolio(/*[in]*/long nargout, /*[in,out]*/VARIANT* 
                                           results, /*[in,out]*/VARIANT* earnings, 
                                           /*[in]*/VARIANT assets, /*[in]*/VARIANT 
                                           startDate, /*[in]*/VARIANT endDate); 

  HRESULT __stdcall simulatePlantPortfolio(/*[in]*/long nargout, /*[in,out]*/VARIANT* 
                                           assetResults, /*[in,out]*/VARIANT* 
                                           portResults, /*[in]*/VARIANT assets, 
                                           /*[in]*/VARIANT startDate, /*[in]*/VARIANT 
                                           endDate, /*[in]*/VARIANT Ntrials); 

};
#endif
